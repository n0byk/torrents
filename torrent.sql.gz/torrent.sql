-- phpMyAdmin SQL Dump
-- version 3.3.2deb1ubuntu1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 16, 2012 at 07:03 PM
-- Server version: 5.1.66
-- PHP Version: 5.3.2-1ubuntu4.18

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `torrent`
--

-- --------------------------------------------------------

--
-- Table structure for table `xbt_comments`
--

CREATE TABLE IF NOT EXISTS `xbt_comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_master` int(11) unsigned NOT NULL,
  `id_slave` int(11) unsigned NOT NULL,
  `comment` varchar(255) NOT NULL,
  `email` char(65) NOT NULL,
  `addip` char(15) NOT NULL,
  `addtime` int(11) NOT NULL,
  `ban` char(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `xbt_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `xbt_config`
--

CREATE TABLE IF NOT EXISTS `xbt_config` (
  `name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `value` varchar(255) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `xbt_config`
--

INSERT INTO `xbt_config` (`name`, `value`) VALUES
('torrent_pass_private_key', 'oQ99RrkzMeANfbhvib9agulsUI1'),
('auto_register', '1');

-- --------------------------------------------------------

--
-- Table structure for table `xbt_deny_from_hosts`
--

CREATE TABLE IF NOT EXISTS `xbt_deny_from_hosts` (
  `begin` int(10) unsigned NOT NULL,
  `end` int(10) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `xbt_deny_from_hosts`
--


-- --------------------------------------------------------

--
-- Table structure for table `xbt_files`
--

CREATE TABLE IF NOT EXISTS `xbt_files` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `info_hash` binary(20) NOT NULL,
  `leechers` int(11) NOT NULL DEFAULT '0',
  `seeders` int(11) NOT NULL DEFAULT '0',
  `completed` int(11) NOT NULL DEFAULT '0',
  `flags` int(11) NOT NULL DEFAULT '0',
  `mtime` int(11) NOT NULL,
  `ctime` int(11) NOT NULL,
  PRIMARY KEY (`fid`),
  UNIQUE KEY `info_hash` (`info_hash`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `xbt_files`
--

INSERT INTO `xbt_files` (`fid`, `info_hash`, `leechers`, `seeders`, `completed`, `flags`, `mtime`, `ctime`) VALUES
(1, '��+y�\n�;=6��X媎1��', 0, 0, 0, 0, 1350476427, 1350476427),
(2, '�Q�SFvkSuD��,燁�', 0, 0, 0, 0, 1352768178, 1352768178);

-- --------------------------------------------------------

--
-- Table structure for table `xbt_files_users`
--

CREATE TABLE IF NOT EXISTS `xbt_files_users` (
  `fid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL,
  `announced` int(11) NOT NULL,
  `completed` int(11) NOT NULL,
  `downloaded` bigint(20) unsigned NOT NULL,
  `left` bigint(20) unsigned NOT NULL,
  `uploaded` bigint(20) unsigned NOT NULL,
  `mtime` int(11) NOT NULL,
  UNIQUE KEY `fid` (`fid`,`uid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `xbt_files_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `xbt_torrents`
--

CREATE TABLE IF NOT EXISTS `xbt_torrents` (
  `tid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tor_hash` binary(20) NOT NULL,
  `title` char(250) NOT NULL,
  `description` mediumtext NOT NULL,
  `category` varchar(40) NOT NULL,
  `addip` char(15) NOT NULL,
  `addtime` int(11) NOT NULL,
  `email` varchar(65) NOT NULL,
  `ban` char(5) NOT NULL DEFAULT '0',
  `size` int(11) NOT NULL,
  `clickcount` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `tor_hash` (`tor_hash`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `xbt_torrents`
--

INSERT INTO `xbt_torrents` (`tid`, `tor_hash`, `title`, `description`, `category`, `addip`, `addtime`, `email`, `ban`, `size`, `clickcount`) VALUES
(1, '��+y�\n�;=6��X媎1��', 'Орда (Андрей Прошкин) [2012, история, HQRip] [Лицензия]', 'clean<br/>\r\n<br/>\r\n(blitz ≥ 0.4.10)<br/>\r\nclean — очистить переменные и итерации контекста<br/>\r\n<br/>\r\nbool clean ( [ string context_path = ''/'' [, bool warn_notfound = true ]] )<br/>\r\n<br/>\r\n$Tpl-&gt;clean($context_path) очищает переменные и итерации контекста. Параметр $context_path по умолчанию равен корню (/) — $Tpl-&gt;clean() без параметров очистит все переменные и итерации шаблона.<br/>\r\n<br/>\r\nВторой параметр управляет генерацией предупреждения PHP когда очищаемая итерация не найдена, по умолчанию true.', 'Камызяк', '127.0.0.1', 1350471008, 'n0byk@yandex.ru', '0', 2097152, 247),
(2, '�Q�SFvkSuD��,燁�', 'The Walking Dead: Episode 1 — 3 (2012) PC', '123 weqe qwe qwe <br/>\r\ngfg fdgfd', 'Ачинск', '127.0.0.1', 1350474212, 'asd@asd.ru', '0', 32768, 303),
(3, 'h��Zk?;蹿�����V��', 'asdasdasd', '213123123', '', '', 0, '', '0', 0, 1),
(4, '�\rZ�G�R���9D�=Q����', 'sdasdas', 'sddadasd', '', '', 0, '', '0', 0, 0),
(5, '�\rZ�G�R���9#�=S����', 'a sdadasd', '123 12edas dad asd ', '', '', 0, '', '0', 0, 2),
(6, 'h��Zk?;貿����V��', '12312', '123123', '', '', 0, '', '0', 0, 0),
(7, '�\rZ�G�R����D�=S����', '123213', '12312312', '', '', 0, '', '0', 0, 0),
(8, '� �p��c`}�2y����\\"', '123123', '123123', '', '', 0, '', '0', 0, 1),
(9, '�\rZ�G�R����D�=S����', 'asdas', 'dasdasd', '', '', 0, '', '0', 0, 2),
(10, '1#1#\0\0\0\0\0\0\0\0\0\0\0\0\0', '12312', '3123', '', '', 0, '', '0', 0, 2),
(11, '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 'as d asd', 'a sda sd', '', '', 0, '', '0', 0, 12),
(12, 'X�Sr+�Ic��������', 'Отбросы / Долбанутые / Плохие / Misfits [04х01-02] (2012) WEB-DL', 'Отбросы / Долбанутые / Плохие<br/>\r\nMisfits<br/>\r\n<br/>\r\nНазвание: Отбросы (Долбанутые)<br/>\r\nОригинальное название: Misfits<br/>\r\nГод выпуска: 2012<br/>\r\nЖанр: Комедия, фантастика<br/>\r\nВыпущено: Великобритания, Clerkenwell Films<br/>\r\nРежиссер: Нирпал Бхогал<br/>\r\nВ ролях: Карла Кроум, Джозеф Гилган, Нейтан МакМаллен, Натан Стюарт-Джарретт, Мэттью МакНалти, Натаниэль Мартелло-Уайт, Шон Дули<br/>\r\n<br/>\r\nВ четвертом сезоне появятся три новых персонажа: Джесс — умная, острая на язык девушка, своего рода Ларри Дэвид в юбке. Такие люди как она говорят на табуированные темы, нарушают социальные нормы и этикет. Джесс ненавидит людей, которые врут ей и несут ахинею.<br/>\r\nФинн — наивный оптимист, всегда старается угодить всем. Очень много болтает, что частенько помогает ему выпутаться из трудного положения. Уморительный чувак.<br/>\r\nАлекс — самый любовьуальный парень на исправительных работах, красавчик, его хотят все девушки. Но почему-то он с ними холоден, кажется девушки его не интересуют. Окружающие считают такое поведение очень подозрительным и предполагают, что это связано с его суперспособностью.<br/>\r\nПодростки, совершившие мелкие преступления, трудятся на общественных работах. Они — не друзья. Более того, у них нет ничего общего, и в их группе постоянно происходят конфликты. Но в один ненастный день разряд молнии делает из них супергероев! Подростки понятия не имеют, что с этим делать. Но судьба им припасла новые испытания, ведь после ненастья сверхспособностями стали обладать не только они…<br/>\r\n<br/>\r\nВнимание! Присутствует ненормативная лексика!<br/>\r\n<br/>\r\nКачество: WEB-DLRip<br/>\r\nВидео: XviD, ~ 1990 Кбит/с, 720x400<br/>\r\nАудио: Русский (AC3, 2 ch, 192 Кбит/с), английский (AC3, 2 ch, 192 Кбит/с)', 'Белозёрский', '127.0.0.1', 1352218057, 'n0byk@yandex.com', '0', 1652895744, 258),
(13, '� �p��c`}�:y����\\"', 'example_add_tracker.torrent', 'фывфывфыв', 'Санкт-Петербург', '127.0.0.1', 1352766666, 'n0byk@yandex.com', '1', 50926464, 0);

-- --------------------------------------------------------

--
-- Table structure for table `xbt_users`
--

CREATE TABLE IF NOT EXISTS `xbt_users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `torrent_pass_version` int(11) NOT NULL DEFAULT '0',
  `downloaded` bigint(20) unsigned NOT NULL DEFAULT '0',
  `uploaded` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `xbt_users`
--

