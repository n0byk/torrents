#NoCSRF, a simple PHP5 token class to prevent CSRF attacks.

* [Website](http://bkcore.com/blog/code/nocsrf-php-class.html)
* Author: Thibaut Despoulain
* Version: 1.0
* Licensed under the MIT license <http://www.opensource.org/licenses/mit-license.php>